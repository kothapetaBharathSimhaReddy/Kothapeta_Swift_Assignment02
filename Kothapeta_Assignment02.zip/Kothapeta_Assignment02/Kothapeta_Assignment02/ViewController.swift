//
//  ViewController.swift
//  Kothapeta_Assignment02
//
//  Created by Bharath Simha Reddy Kothapeta on 9/12/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var dateOutlet: UIDatePicker!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

    }

    @IBAction func SubmitBTN(_ sender: UIButton) {
        
        if let name = nameOutlet?.text, !name.isEmpty,
           let billAmountText = billAmountOutlet?.text, !billAmountText.isEmpty,
           let billAmount = Double(billAmountText) {
            var finalBillAmount: Double

            if billAmount >= 500 {
                finalBillAmount = billAmount - 50
            } else {
                finalBillAmount = billAmount
            }
            if let tipPercentageText = tipPercentageOutlet?.text, !tipPercentageText.isEmpty,
               let tipPercentage = Double(tipPercentageText) {
                
                let tipAmount = (finalBillAmount * tipPercentage) / 100
                let totalAmount = finalBillAmount + tipAmount
                
                if let date = dateOutlet?.date {
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "MM-dd-yyyy hh:mm:ss"
                    dateFormatter.timeZone = TimeZone(identifier: "America/Missouri")
                    let formattedDate = dateFormatter.string(from: date)
                    
                    // Update UI labels with computed values
                    nameLabel?.text = "Name: \(name)"
                    billAmountLabel?.text = "Bill Amount: $\(billAmountText)"
                    tipAmountLabel?.text = "Tip Amount: $\(tipAmount)"
                    totalAmountLabel?.text = "Total Amount: $\(totalAmount)"
                    dateLabel?.text = "\(formattedDate)"
                }
            }
        }
    }
    
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        nameLabel?.text = ""
        billAmountLabel?.text = ""
        tipAmountLabel?.text = ""
        totalAmountLabel?.text = ""
        dateLabel?.text = ""
        nameOutlet?.text = ""
        nameOutlet?.becomeFirstResponder()
        billAmountOutlet?.text = ""
        tipPercentageOutlet?.text = ""
        
    }
}
